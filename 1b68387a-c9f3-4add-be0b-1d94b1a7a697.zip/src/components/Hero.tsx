import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Terminal, Activity, Database, Cpu } from 'lucide-react';
export function Hero() {
  return (
    <section className="relative min-h-screen pt-32 pb-20 overflow-hidden flex flex-col items-center justify-center">
      {/* Background Grid */}
      <div className="absolute inset-0 w-full h-full overflow-hidden">
        <div className="perspective-grid"></div>
        {/* Glow effects */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[400px] bg-accent-primary/20 blur-[120px] rounded-full pointer-events-none"></div>
        <div className="absolute top-1/3 left-1/2 -translate-x-1/4 w-[400px] h-[300px] bg-accent-secondary/20 blur-[100px] rounded-full pointer-events-none"></div>
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10 w-full flex flex-col items-center text-center">
        <motion.div
          initial={{
            opacity: 0,
            y: 20
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          transition={{
            duration: 0.6
          }}
          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-bg-secondary border border-border mb-8">
          
          <span className="flex h-2 w-2 rounded-full bg-accent-secondary"></span>
          <span className="text-xs font-medium text-text-secondary">
            AE Studio v3.0 is now available
          </span>
        </motion.div>

        <motion.h1
          initial={{
            opacity: 0,
            y: 20
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          transition={{
            duration: 0.6,
            delay: 0.1
          }}
          className="text-5xl md:text-7xl font-bold tracking-tightest text-text-primary max-w-4xl mb-6 leading-[1.1]">
          
          Precision engineering for <br className="hidden md:block" />
          <span className="gradient-text">automotive systems.</span>
        </motion.h1>

        <motion.p
          initial={{
            opacity: 0,
            y: 20
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          transition={{
            duration: 0.6,
            delay: 0.2
          }}
          className="text-lg md:text-xl text-text-secondary max-w-2xl mb-10">
          
          Embedded software, diagnostic tools, and custom hardware solutions for
          OEMs and Tier 1/2 suppliers. Built for ISO 26262 compliance.
        </motion.p>

        <motion.div
          initial={{
            opacity: 0,
            y: 20
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          transition={{
            duration: 0.6,
            delay: 0.3
          }}
          className="flex flex-col sm:flex-row items-center gap-4 mb-20">
          
          <button className="w-full sm:w-auto px-8 py-3.5 rounded-lg bg-text-primary text-bg-primary font-medium flex items-center justify-center gap-2 hover:opacity-90 transition-opacity">
            Start a Project <ArrowRight className="w-4 h-4" />
          </button>
          <button className="w-full sm:w-auto px-8 py-3.5 rounded-lg bg-bg-secondary border border-border text-text-primary font-medium hover:bg-bg-surface transition-colors">
            Explore Tools
          </button>
        </motion.div>

        {/* Stylized Product Mockup */}
        <motion.div
          initial={{
            opacity: 0,
            y: 40
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          transition={{
            duration: 0.8,
            delay: 0.4
          }}
          className="w-full max-w-5xl rounded-xl border border-border bg-bg-surface shadow-2xl overflow-hidden flex flex-col relative">
          
          {/* Mockup Header */}
          <div className="h-12 border-b border-border flex items-center px-4 justify-between bg-bg-secondary/50">
            <div className="flex items-center gap-4">
              <div className="flex gap-1.5">
                <div className="w-3 h-3 rounded-full bg-red-500/80"></div>
                <div className="w-3 h-3 rounded-full bg-yellow-500/80"></div>
                <div className="w-3 h-3 rounded-full bg-green-500/80"></div>
              </div>
              <div className="hidden sm:flex items-center gap-2 text-xs font-mono text-text-secondary bg-bg-primary px-2 py-1 rounded border border-border">
                <Terminal className="w-3 h-3" /> AE_BusAnalyzer_Pro
              </div>
            </div>
            <div className="flex items-center gap-3 text-xs font-mono text-text-secondary">
              <span className="flex items-center gap-1">
                <Activity className="w-3 h-3 text-accent-secondary" /> CAN1:
                Online
              </span>
              <span className="flex items-center gap-1">
                <Database className="w-3 h-3 text-accent-primary" /> Logging
              </span>
            </div>
          </div>

          {/* Mockup Body */}
          <div className="flex flex-col md:flex-row h-[400px] bg-bg-primary text-left">
            {/* Sidebar Tree */}
            <div className="w-full md:w-64 border-r border-border p-3 flex flex-col gap-1 text-xs font-mono text-text-secondary overflow-y-auto bg-bg-surface/30">
              <div className="text-text-primary font-medium mb-2 px-2 flex items-center gap-2">
                <Cpu className="w-3 h-3" /> Network Topology
              </div>
              <div className="text-text-primary bg-accent-primary/10 px-2 py-1.5 rounded border border-accent-primary/20">
                ▼ CAN_Powertrain
              </div>
              <div className="pl-4 py-1 hover:text-text-primary cursor-pointer">
                {' '}
                ├─ ECU_EngineControl
              </div>
              <div className="pl-4 py-1 text-accent-secondary">
                {' '}
                ├─ ECU_Transmission
              </div>
              <div className="pl-4 py-1 hover:text-text-primary cursor-pointer">
                {' '}
                └─ ECU_BrakeSystem
              </div>
              <div className="mt-2 text-text-primary px-2 py-1.5 rounded hover:bg-bg-secondary cursor-pointer">
                ▶ CAN_Infotainment
              </div>
              <div className="text-text-primary px-2 py-1.5 rounded hover:bg-bg-secondary cursor-pointer">
                ▶ LIN_BodyControl
              </div>
            </div>

            {/* Main Data Table */}
            <div className="flex-1 overflow-hidden flex flex-col">
              {/* Tabs */}
              <div className="flex border-b border-border bg-bg-surface/50 text-xs font-mono">
                <div className="px-4 py-2 border-b-2 border-accent-primary text-text-primary">
                  Trace
                </div>
                <div className="px-4 py-2 text-text-secondary hover:text-text-primary cursor-pointer">
                  Signals
                </div>
                <div className="px-4 py-2 text-text-secondary hover:text-text-primary cursor-pointer">
                  Graphics
                </div>
                <div className="px-4 py-2 text-text-secondary hover:text-text-primary cursor-pointer">
                  Diagnostics
                </div>
              </div>

              {/* Table Header */}
              <div className="grid grid-cols-6 border-b border-border px-4 py-2 text-xs font-mono text-text-secondary bg-bg-secondary/30">
                <div>Time</div>
                <div>ID (Hex)</div>
                <div className="col-span-2">Name</div>
                <div>DLC</div>
                <div>Data (Hex)</div>
              </div>

              {/* Table Rows */}
              <div className="flex flex-col text-xs font-mono overflow-y-auto">
                {[
                {
                  time: '12.0041',
                  id: '0x0C1',
                  name: 'Engine_Data_Fast',
                  dlc: '8',
                  data: 'FF 00 A1 2B 00 00 00 00',
                  highlight: false
                },
                {
                  time: '12.0052',
                  id: '0x1A4',
                  name: 'Trans_Status',
                  dlc: '8',
                  data: '01 4A 00 00 00 00 00 00',
                  highlight: true
                },
                {
                  time: '12.0089',
                  id: '0x2B0',
                  name: 'Wheel_Speeds',
                  dlc: '8',
                  data: '1A 2B 1A 2C 1A 2A 1A 2B',
                  highlight: false
                },
                {
                  time: '12.0101',
                  id: '0x0C1',
                  name: 'Engine_Data_Fast',
                  dlc: '8',
                  data: 'FF 00 A2 2B 00 00 00 00',
                  highlight: false
                },
                {
                  time: '12.0150',
                  id: '0x3C2',
                  name: 'Brake_Pressure',
                  dlc: '4',
                  data: '0A 14 00 00',
                  highlight: false
                },
                {
                  time: '12.0182',
                  id: '0x1A4',
                  name: 'Trans_Status',
                  dlc: '8',
                  data: '01 4B 00 00 00 00 00 00',
                  highlight: true
                },
                {
                  time: '12.0205',
                  id: '0x4F0',
                  name: 'Steering_Angle',
                  dlc: '6',
                  data: '00 12 00 00 00 00',
                  highlight: false
                }].
                map((row, i) =>
                <div
                  key={i}
                  className={`grid grid-cols-6 px-4 py-2 border-b border-border/30 hover:bg-bg-secondary/50 cursor-pointer ${row.highlight ? 'bg-accent-secondary/5 text-text-primary' : 'text-text-secondary'}`}>
                  
                    <div className="text-text-secondary/70">{row.time}</div>
                    <div
                    className={
                    row.highlight ?
                    'text-accent-secondary' :
                    'text-accent-primary'
                    }>
                    
                      {row.id}
                    </div>
                    <div className="col-span-2">{row.name}</div>
                    <div>{row.dlc}</div>
                    <div className="tracking-widest">{row.data}</div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>);

}