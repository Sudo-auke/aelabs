import React, { useState } from 'react';
import { useTheme } from '../hooks/useTheme';
import { useScrollPosition } from '../hooks/useScrollPosition';
import { Moon, Sun, Menu, X, ChevronDown } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
interface HeaderProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}
export function Header({ currentPage, onNavigate }: HeaderProps) {
  const { isDark, toggleTheme } = useTheme();
  const scrollY = useScrollPosition();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [lang, setLang] = useState('EN');
  const isScrolled = scrollY > 50;
  const navLinks = [
  {
    name: 'Solutions',
    id: 'solutions'
  },
  {
    name: 'About',
    id: 'about'
  },
  {
    name: 'Contact',
    id: 'contact'
  }];

  const handleNavClick = (e: React.MouseEvent, id: string) => {
    e.preventDefault();
    onNavigate(id);
    setIsMobileMenuOpen(false);
  };
  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-bg-primary/80 backdrop-blur-xl border-b border-border py-3' : 'bg-transparent py-5'}`}>
        
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
          {/* Logo */}
          <div
            className="flex items-center gap-2 cursor-pointer"
            onClick={(e) => handleNavClick(e, 'home')}>
            
            <div className="w-8 h-8 rounded bg-accent-primary flex items-center justify-center">
              <span className="text-white font-bold tracking-tighter text-sm">
                AE
              </span>
            </div>
            <span className="font-bold text-xl tracking-tightest text-text-primary">
              Labs
            </span>
          </div>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) =>
            <a
              key={link.name}
              href={`#${link.id}`}
              onClick={(e) => handleNavClick(e, link.id)}
              className={`text-sm font-medium transition-colors ${currentPage === link.id ? 'text-text-primary' : 'text-text-secondary hover:text-text-primary'}`}>
              
                {link.name}
              </a>
            )}
          </nav>

          {/* Actions */}
          <div className="hidden md:flex items-center gap-4">
            {/* Language Switcher */}
            <button className="flex items-center gap-1 text-sm font-medium text-text-secondary hover:text-text-primary transition-colors">
              {lang} <ChevronDown className="w-4 h-4" />
            </button>

            {/* Theme Toggle */}
            <button
              onClick={toggleTheme}
              className="p-2 rounded-full hover:bg-bg-secondary text-text-secondary hover:text-text-primary transition-colors"
              aria-label="Toggle theme">
              
              {isDark ?
              <Sun className="w-4 h-4" /> :

              <Moon className="w-4 h-4" />
              }
            </button>

            {/* CTA */}
            <button
              onClick={(e) => handleNavClick(e, 'contact')}
              className="px-4 py-2 text-sm font-medium bg-text-primary text-bg-primary rounded-lg hover:opacity-90 transition-opacity">
              
              Contact Sales
            </button>
          </div>

          {/* Mobile Menu Toggle */}
          <button
            className="md:hidden p-2 text-text-primary"
            onClick={() => setIsMobileMenuOpen(true)}>
            
            <Menu className="w-6 h-6" />
          </button>
        </div>
      </header>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen &&
        <motion.div
          initial={{
            opacity: 0,
            y: -20
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          exit={{
            opacity: 0,
            y: -20
          }}
          className="fixed inset-0 z-[60] bg-bg-primary p-6 flex flex-col">
          
            <div className="flex items-center justify-between mb-12">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded bg-accent-primary flex items-center justify-center">
                  <span className="text-white font-bold tracking-tighter text-sm">
                    AE
                  </span>
                </div>
                <span className="font-bold text-xl tracking-tightest text-text-primary">
                  Labs
                </span>
              </div>
              <button
              onClick={() => setIsMobileMenuOpen(false)}
              className="p-2 text-text-primary">
              
                <X className="w-6 h-6" />
              </button>
            </div>

            <nav className="flex flex-col gap-6 text-2xl font-bold tracking-tightest">
              {navLinks.map((link) =>
            <a
              key={link.name}
              href={`#${link.id}`}
              className={`${currentPage === link.id ? 'text-accent-primary' : 'text-text-primary'} hover:text-accent-primary transition-colors`}
              onClick={(e) => handleNavClick(e, link.id)}>
              
                  {link.name}
                </a>
            )}
            </nav>

            <div className="mt-auto flex flex-col gap-6">
              <div className="flex items-center justify-between border-t border-border pt-6">
                <span className="text-text-secondary font-medium">Theme</span>
                <button
                onClick={toggleTheme}
                className="p-3 rounded-full bg-bg-secondary text-text-primary">
                
                  {isDark ?
                <Sun className="w-5 h-5" /> :

                <Moon className="w-5 h-5" />
                }
                </button>
              </div>
              <button
              onClick={(e) => handleNavClick(e, 'contact')}
              className="w-full py-4 text-center font-medium bg-text-primary text-bg-primary rounded-xl">
              
                Contact Sales
              </button>
            </div>
          </motion.div>
        }
      </AnimatePresence>
    </>);

}