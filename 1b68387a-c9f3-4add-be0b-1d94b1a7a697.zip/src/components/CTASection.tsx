import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
export function CTASection() {
  return (
    <section className="py-24 relative overflow-hidden bg-bg-secondary">
      {/* Background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-accent-primary/10 blur-[120px] rounded-full pointer-events-none"></div>

      <div className="max-w-4xl mx-auto px-6 relative z-10 text-center">
        <motion.h2
          initial={{
            opacity: 0,
            y: 20
          }}
          whileInView={{
            opacity: 1,
            y: 0
          }}
          viewport={{
            once: true
          }}
          transition={{
            duration: 0.5
          }}
          className="text-4xl md:text-5xl font-bold tracking-tightest text-text-primary mb-6">
          
          Ready to accelerate your next project?
        </motion.h2>

        <motion.p
          initial={{
            opacity: 0,
            y: 20
          }}
          whileInView={{
            opacity: 1,
            y: 0
          }}
          viewport={{
            once: true
          }}
          transition={{
            duration: 0.5,
            delay: 0.1
          }}
          className="text-xl text-text-secondary mb-10 max-w-2xl mx-auto">
          
          From concept to production — we deliver embedded excellence for the
          automotive industry.
        </motion.p>

        <motion.div
          initial={{
            opacity: 0,
            y: 20
          }}
          whileInView={{
            opacity: 1,
            y: 0
          }}
          viewport={{
            once: true
          }}
          transition={{
            duration: 0.5,
            delay: 0.2
          }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4">
          
          <button className="w-full sm:w-auto px-8 py-4 rounded-lg bg-accent-primary text-white font-medium flex items-center justify-center gap-2 hover:bg-accent-primary/90 transition-colors shadow-glow">
            Get a Quote <ArrowRight className="w-4 h-4" />
          </button>
          <button className="w-full sm:w-auto px-8 py-4 rounded-lg bg-bg-surface border border-border text-text-primary font-medium hover:bg-bg-secondary transition-colors">
            View Our Work
          </button>
        </motion.div>
      </div>
    </section>);

}