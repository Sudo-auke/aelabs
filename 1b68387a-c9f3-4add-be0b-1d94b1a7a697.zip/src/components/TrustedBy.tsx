import React from 'react';
const companies = ['Stellantis', 'Bosch', 'Continental', 'Forvia', 'Valeo'];
export function TrustedBy() {
  return (
    <section className="py-16 bg-bg-primary overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <p className="text-center text-sm font-medium text-text-secondary uppercase tracking-widest mb-8">
          Trusted by industry leaders
        </p>
        <div className="flex flex-wrap justify-center items-center gap-8 md:gap-16 opacity-50 grayscale hover:grayscale-0 transition-all duration-500">
          {companies.map((company) =>
          <div
            key={company}
            className="text-xl md:text-2xl font-bold tracking-tightest text-text-primary">
            
              {company}
            </div>
          )}
        </div>
      </div>
    </section>);

}