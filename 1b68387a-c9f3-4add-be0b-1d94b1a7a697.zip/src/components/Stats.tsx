import React from 'react';
import { motion } from 'framer-motion';
const stats = [
{
  value: '15+',
  label: 'Years Experience'
},
{
  value: '200+',
  label: 'Projects Delivered'
},
{
  value: '40+',
  label: 'Global Clients'
},
{
  value: 'ISO',
  label: '26262 Certified'
}];

export function Stats() {
  return (
    <section className="py-20 border-y border-border bg-bg-secondary/30">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-12">
          {stats.map((stat, index) =>
          <motion.div
            key={stat.label}
            initial={{
              opacity: 0,
              scale: 0.9
            }}
            whileInView={{
              opacity: 1,
              scale: 1
            }}
            viewport={{
              once: true
            }}
            transition={{
              duration: 0.5,
              delay: index * 0.1
            }}
            className="flex flex-col items-center text-center">
            
              <div className="text-4xl md:text-5xl font-bold tracking-tightest mb-2 gradient-text">
                {stat.value}
              </div>
              <div className="text-sm md:text-base font-medium text-text-secondary uppercase tracking-wider">
                {stat.label}
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </section>);

}