import React from 'react';
import { motion } from 'framer-motion';
import { Code2, Wrench, Cpu, ArrowRight } from 'lucide-react';
const solutions = [
{
  title: 'Embedded Software',
  description:
  'AUTOSAR compliant basic software, complex device drivers, and application layer development for modern ECUs.',
  icon: Code2,
  color: 'text-accent-primary',
  bg: 'bg-accent-primary/10'
},
{
  title: 'Engineering Tools',
  description:
  'Custom PC-based diagnostic tools, bus analyzers (CAN, LIN, Ethernet), and automated testing frameworks.',
  icon: Wrench,
  color: 'text-accent-secondary',
  bg: 'bg-accent-secondary/10'
},
{
  title: 'Custom Hardware',
  description:
  'Rapid prototyping platforms, custom gateways, and HIL (Hardware-in-the-Loop) test system integration.',
  icon: Cpu,
  color: 'text-text-primary',
  bg: 'bg-text-primary/10'
}];

export function SolutionCards() {
  return (
    <section className="py-24 bg-bg-primary relative">
      <div className="max-w-7xl mx-auto px-6">
        <div className="mb-16 md:text-center">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tightest text-text-primary mb-4">
            End-to-end engineering solutions
          </h2>
          <p className="text-lg text-text-secondary max-w-2xl mx-auto">
            We provide the foundational technology and tools required to build
            the next generation of software-defined vehicles.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {solutions.map((solution, index) =>
          <motion.div
            key={solution.title}
            initial={{
              opacity: 0,
              y: 20
            }}
            whileInView={{
              opacity: 1,
              y: 0
            }}
            viewport={{
              once: true
            }}
            transition={{
              duration: 0.5,
              delay: index * 0.1
            }}
            className="group relative p-8 rounded-2xl bg-bg-surface border border-border hover:border-accent-primary/30 transition-all duration-300 hover:scale-[1.02] hover:shadow-glow">
            
              <div
              className={`w-12 h-12 rounded-full ${solution.bg} flex items-center justify-center mb-6`}>
              
                <solution.icon className={`w-6 h-6 ${solution.color}`} />
              </div>
              <h3 className="text-xl font-bold text-text-primary mb-3 tracking-tightest">
                {solution.title}
              </h3>
              <p className="text-text-secondary mb-8 leading-relaxed">
                {solution.description}
              </p>
              <div className="flex items-center text-sm font-medium text-text-primary group-hover:text-accent-primary transition-colors mt-auto">
                Learn more{' '}
                <ArrowRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </section>);

}