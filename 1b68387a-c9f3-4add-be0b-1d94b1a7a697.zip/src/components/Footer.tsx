import React from 'react';
import { Linkedin, Github, Twitter } from 'lucide-react';
export function Footer() {
  return (
    <footer className="bg-bg-surface border-t border-border py-16">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          {/* Brand Col */}
          <div className="flex flex-col gap-6">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded bg-accent-primary flex items-center justify-center">
                <span className="text-white font-bold tracking-tighter text-sm">
                  AE
                </span>
              </div>
              <span className="font-bold text-xl tracking-tightest text-text-primary">
                Labs
              </span>
            </div>
            <p className="text-sm text-text-secondary leading-relaxed">
              Precision engineering for automotive systems. Embedded software,
              diagnostic tools, and custom hardware solutions.
            </p>
            <div className="flex items-center gap-4 text-text-secondary">
              <a href="#" className="hover:text-text-primary transition-colors">
                <Linkedin className="w-5 h-5" />
              </a>
              <a href="#" className="hover:text-text-primary transition-colors">
                <Github className="w-5 h-5" />
              </a>
              <a href="#" className="hover:text-text-primary transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Solutions Col */}
          <div>
            <h4 className="font-bold text-text-primary mb-4">Solutions</h4>
            <ul className="space-y-3 text-sm text-text-secondary">
              <li>
                <a
                  href="#"
                  className="hover:text-text-primary transition-colors">
                  
                  Embedded Software
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="hover:text-text-primary transition-colors">
                  
                  Engineering Tools
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="hover:text-text-primary transition-colors">
                  
                  Custom Hardware
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="hover:text-text-primary transition-colors">
                  
                  AUTOSAR Integration
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="hover:text-text-primary transition-colors">
                  
                  ISO 26262 Consulting
                </a>
              </li>
            </ul>
          </div>

          {/* Resources Col */}
          <div>
            <h4 className="font-bold text-text-primary mb-4">Resources</h4>
            <ul className="space-y-3 text-sm text-text-secondary">
              <li>
                <a
                  href="#"
                  className="hover:text-text-primary transition-colors">
                  
                  Documentation
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="hover:text-text-primary transition-colors">
                  
                  API Reference
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="hover:text-text-primary transition-colors">
                  
                  Case Studies
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="hover:text-text-primary transition-colors">
                  
                  Blog
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="hover:text-text-primary transition-colors">
                  
                  Support Portal
                </a>
              </li>
            </ul>
          </div>

          {/* Company Col */}
          <div>
            <h4 className="font-bold text-text-primary mb-4">Company</h4>
            <ul className="space-y-3 text-sm text-text-secondary">
              <li>
                <a
                  href="#"
                  className="hover:text-text-primary transition-colors">
                  
                  About Us
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="hover:text-text-primary transition-colors">
                  
                  Careers
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="hover:text-text-primary transition-colors">
                  
                  Contact
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="hover:text-text-primary transition-colors">
                  
                  Partners
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="hover:text-text-primary transition-colors">
                  
                  Legal & Privacy
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-border flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-text-secondary">
          <div>
            © {new Date().getFullYear()} AE Labs GmbH. All rights reserved.
          </div>
          <div className="flex gap-6">
            <a href="#" className="hover:text-text-primary transition-colors">
              Privacy Policy
            </a>
            <a href="#" className="hover:text-text-primary transition-colors">
              Terms of Service
            </a>
            <a href="#" className="hover:text-text-primary transition-colors">
              Imprint
            </a>
          </div>
        </div>
      </div>
    </footer>);

}