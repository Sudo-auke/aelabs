import React from 'react';
import { motion } from 'framer-motion';
import {
  ShieldCheck,
  Award,
  CheckCircle2,
  Target,
  Zap,
  Users } from
'lucide-react';
import { CTASection } from '../components/CTASection';
const certs = [
{
  title: 'ISO 26262',
  subtitle: 'ASIL-D Compliant',
  description:
  'Our development processes meet the highest standards for functional safety in road vehicles.',
  icon: ShieldCheck,
  color: 'text-accent-primary'
},
{
  title: 'ASPICE',
  subtitle: 'Level 2 Certified',
  description:
  'Automotive SPICE compliant software engineering processes ensuring predictable quality.',
  icon: Award,
  color: 'text-accent-secondary'
},
{
  title: 'ISO 9001',
  subtitle: 'Quality Management',
  description:
  'Certified quality management systems applied across all engineering disciplines.',
  icon: CheckCircle2,
  color: 'text-text-primary'
}];

const values = [
{
  title: 'Precision',
  description:
  'In embedded systems, close enough is not enough. We engineer with exactness.',
  icon: Target
},
{
  title: 'Innovation',
  description:
  'Pushing the boundaries of what software-defined vehicles can achieve.',
  icon: Zap
},
{
  title: 'Partnership',
  description:
  'We integrate deeply with your teams, acting as an extension of your engineering capacity.',
  icon: Users
}];

const team = [
{
  name: 'Dr. Marcus Weber',
  role: 'Founder & CEO',
  initials: 'MW'
},
{
  name: 'Sarah Chen',
  role: 'Head of Embedded Software',
  initials: 'SC'
},
{
  name: 'Thomas Müller',
  role: 'Lead Hardware Engineer',
  initials: 'TM'
},
{
  name: 'Elena Rodriguez',
  role: 'Director of Tooling',
  initials: 'ER'
},
{
  name: 'James Wilson',
  role: 'Functional Safety Manager',
  initials: 'JW'
},
{
  name: 'Anna Kowalski',
  role: 'Head of Operations',
  initials: 'AK'
}];

export function About() {
  return (
    <div className="pt-32 pb-0 min-h-screen">
      {/* Hero */}
      <div className="max-w-7xl mx-auto px-6 mb-24 md:text-center">
        <motion.h1
          initial={{
            opacity: 0,
            y: 20
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          className="text-4xl md:text-6xl font-bold tracking-tightest text-text-primary mb-6">
          
          Engineering the{' '}
          <span className="gradient-text">future of mobility.</span>
        </motion.h1>
        <motion.p
          initial={{
            opacity: 0,
            y: 20
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          transition={{
            delay: 0.1
          }}
          className="text-lg md:text-xl text-text-secondary max-w-3xl mx-auto">
          
          Founded in 2015 by former OEM engineers, AE Labs was built on a simple
          premise: automotive software needs better tools and more rigorous
          engineering practices.
        </motion.p>
      </div>

      {/* Story / Timeline */}
      <section className="py-20 bg-bg-secondary border-y border-border">
        <div className="max-w-4xl mx-auto px-6">
          <h2 className="text-3xl font-bold tracking-tightest text-text-primary mb-12 text-center">
            Our Journey
          </h2>

          <div className="space-y-12 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-border before:to-transparent">
            {[
            {
              year: '2015',
              title: 'Foundation',
              desc: 'Started in Stuttgart focusing on custom CAN analysis tools.'
            },
            {
              year: '2018',
              title: 'Embedded Division',
              desc: 'Expanded into AUTOSAR BSW development and integration.'
            },
            {
              year: '2021',
              title: 'ISO 26262 Certification',
              desc: 'Achieved ASIL-D compliance for our core software stacks.'
            },
            {
              year: '2024',
              title: 'Global Expansion',
              desc: 'Opened new offices to support Tier 1 suppliers worldwide.'
            }].
            map((item, i) =>
            <motion.div
              key={item.year}
              initial={{
                opacity: 0,
                y: 20
              }}
              whileInView={{
                opacity: 1,
                y: 0
              }}
              viewport={{
                once: true
              }}
              transition={{
                delay: i * 0.1
              }}
              className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
              
                <div className="flex items-center justify-center w-10 h-10 rounded-full border-4 border-bg-secondary bg-bg-surface text-accent-primary shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 z-10">
                  <div className="w-2 h-2 rounded-full bg-accent-primary"></div>
                </div>
                <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-6 rounded-2xl bg-bg-surface border border-border shadow-sm">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-bold text-text-primary text-lg">
                      {item.title}
                    </h3>
                    <span className="text-sm font-mono text-accent-secondary bg-accent-secondary/10 px-2 py-1 rounded">
                      {item.year}
                    </span>
                  </div>
                  <p className="text-text-secondary">{item.desc}</p>
                </div>
              </motion.div>
            )}
          </div>
        </div>
      </section>

      {/* Certifications */}
      <section className="py-24 max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold tracking-tightest text-text-primary mb-4">
            Quality & Safety
          </h2>
          <p className="text-text-secondary max-w-2xl mx-auto">
            We adhere to the strictest automotive industry standards.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {certs.map((cert, i) =>
          <motion.div
            key={cert.title}
            initial={{
              opacity: 0,
              y: 20
            }}
            whileInView={{
              opacity: 1,
              y: 0
            }}
            viewport={{
              once: true
            }}
            transition={{
              delay: i * 0.1
            }}
            className="p-8 rounded-2xl bg-bg-surface border border-border hover:border-border/80 transition-colors text-center flex flex-col items-center">
            
              <div className="w-16 h-16 rounded-full bg-bg-secondary flex items-center justify-center mb-6">
                <cert.icon className={`w-8 h-8 ${cert.color}`} />
              </div>
              <h3 className="text-2xl font-bold text-text-primary mb-1 tracking-tightest">
                {cert.title}
              </h3>
              <p className="text-sm font-medium text-text-secondary uppercase tracking-widest mb-4">
                {cert.subtitle}
              </p>
              <p className="text-text-secondary">{cert.description}</p>
            </motion.div>
          )}
        </div>
      </section>

      {/* Values */}
      <section className="py-24 bg-bg-secondary border-y border-border">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {values.map((value, i) =>
            <motion.div
              key={value.title}
              initial={{
                opacity: 0,
                y: 20
              }}
              whileInView={{
                opacity: 1,
                y: 0
              }}
              viewport={{
                once: true
              }}
              transition={{
                delay: i * 0.1
              }}>
              
                <value.icon className="w-8 h-8 text-text-primary mb-4" />
                <h3 className="text-xl font-bold text-text-primary mb-3 tracking-tightest">
                  {value.title}
                </h3>
                <p className="text-text-secondary">{value.description}</p>
              </motion.div>
            )}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-24 max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold tracking-tightest text-text-primary mb-4">
            Leadership Team
          </h2>
          <p className="text-text-secondary max-w-2xl mx-auto">
            Decades of combined experience in automotive engineering.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {team.map((member, i) =>
          <motion.div
            key={member.name}
            initial={{
              opacity: 0,
              scale: 0.95
            }}
            whileInView={{
              opacity: 1,
              scale: 1
            }}
            viewport={{
              once: true
            }}
            transition={{
              delay: i * 0.05
            }}
            className="flex items-center gap-4 p-4 rounded-xl hover:bg-bg-secondary transition-colors">
            
              <div className="w-16 h-16 rounded-full bg-bg-surface border border-border flex items-center justify-center text-xl font-bold text-text-secondary shrink-0">
                {member.initials}
              </div>
              <div>
                <h4 className="font-bold text-text-primary">{member.name}</h4>
                <p className="text-sm text-text-secondary">{member.role}</p>
              </div>
            </motion.div>
          )}
        </div>
      </section>

      <CTASection />
    </div>);

}