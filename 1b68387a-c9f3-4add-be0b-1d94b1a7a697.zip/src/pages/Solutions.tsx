import React, { useState, Component } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Code2, Wrench, Cpu, ArrowRight, CheckCircle2 } from 'lucide-react';
import { CTASection } from '../components/CTASection';
type Category =
'All' |
'Embedded Software' |
'Engineering Tools' |
'Custom Hardware';
const solutionsData = [
{
  id: 1,
  title: 'AUTOSAR Integration',
  category: 'Embedded Software',
  description:
  'BSW configuration, RTE generation, and SWC development for modern vehicle architectures.',
  icon: Code2,
  features: [
  'Classic & Adaptive AUTOSAR',
  'MCAL Configuration',
  'Complex Device Drivers']

},
{
  id: 2,
  title: 'Bootloader Development',
  category: 'Embedded Software',
  description:
  'Secure, UDS-based flash bootloaders with dual-bank support and cryptographic verification.',
  icon: Code2,
  features: ['ISO 14229 (UDS)', 'Secure Boot', 'OTA Update Support']
},
{
  id: 3,
  title: 'Diagnostic Stack',
  category: 'Embedded Software',
  description:
  'Comprehensive UDS and OBD-II implementation with advanced DTC management.',
  icon: Code2,
  features: [
  'Dem/Dcm Configuration',
  'OBD-II Compliance',
  'Fault Memory Management']

},
{
  id: 4,
  title: 'CAN/LIN Analysis Tool',
  category: 'Engineering Tools',
  description:
  'Real-time bus monitoring, logging, and simulation with DBC/LDF import and export capabilities.',
  icon: Wrench,
  features: ['Microsecond Precision', 'Signal Plotting', 'Node Simulation']
},
{
  id: 5,
  title: 'Flash Programming Suite',
  category: 'Engineering Tools',
  description:
  'Multi-ECU parallel programming tool for end-of-line production and service centers.',
  icon: Wrench,
  features: [
  'Parallel Flashing',
  'Hex/S19 Management',
  'Production Integration']

},
{
  id: 6,
  title: 'Test Automation Framework',
  category: 'Engineering Tools',
  description:
  'Python-based HIL/SIL test scripting environment with CI/CD pipeline integration.',
  icon: Wrench,
  features: [
  'Jenkins/GitLab CI',
  'Report Generation',
  'Requirement Traceability']

},
{
  id: 7,
  title: 'Rapid Prototyping PCB',
  category: 'Custom Hardware',
  description:
  'Schematic capture, multi-layer PCB design, and fast-turnaround PCBA for proof-of-concepts.',
  icon: Cpu,
  features: [
  'Altium Designer',
  'Automotive Grade Components',
  'Thermal Analysis']

},
{
  id: 8,
  title: 'HIL Test Bench',
  category: 'Custom Hardware',
  description:
  'Custom hardware-in-the-loop test systems with fault injection and signal conditioning.',
  icon: Cpu,
  features: [
  'Real-time Execution',
  'Fault Injection',
  'Custom Breakout Boxes']

}];

export function Solutions() {
  const [activeCategory, setActiveCategory] = useState<Category>('All');
  const categories: Category[] = [
  'All',
  'Embedded Software',
  'Engineering Tools',
  'Custom Hardware'];

  const filteredSolutions = solutionsData.filter(
    (sol) => activeCategory === 'All' || sol.category === activeCategory
  );
  return (
    <div className="pt-32 pb-0 min-h-screen">
      {/* Header */}
      <div className="max-w-7xl mx-auto px-6 mb-16 text-center">
        <motion.h1
          initial={{
            opacity: 0,
            y: 20
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          className="text-4xl md:text-6xl font-bold tracking-tightest text-text-primary mb-6">
          
          Our <span className="gradient-text">Solutions</span>
        </motion.h1>
        <motion.p
          initial={{
            opacity: 0,
            y: 20
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          transition={{
            delay: 0.1
          }}
          className="text-lg md:text-xl text-text-secondary max-w-3xl mx-auto">
          
          Comprehensive engineering services and tools designed specifically for
          the rigorous demands of the automotive industry.
        </motion.p>
      </div>

      {/* Filters */}
      <div className="max-w-7xl mx-auto px-6 mb-12">
        <div className="flex flex-wrap justify-center gap-2 md:gap-4">
          {categories.map((category) =>
          <button
            key={category}
            onClick={() => setActiveCategory(category)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${activeCategory === category ? 'bg-text-primary text-bg-primary shadow-glow' : 'bg-bg-secondary text-text-secondary hover:text-text-primary hover:bg-bg-surface border border-border'}`}>
            
              {category}
            </button>
          )}
        </div>
      </div>

      {/* Grid */}
      <div className="max-w-7xl mx-auto px-6 mb-24 min-h-[600px]">
        <motion.div
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          
          <AnimatePresence mode="popLayout">
            {filteredSolutions.map((solution) =>
            <motion.div
              key={solution.id}
              layout
              initial={{
                opacity: 0,
                scale: 0.9
              }}
              animate={{
                opacity: 1,
                scale: 1
              }}
              exit={{
                opacity: 0,
                scale: 0.9
              }}
              transition={{
                duration: 0.3
              }}
              className="flex flex-col p-8 rounded-2xl bg-bg-surface border border-border hover:border-accent-primary/30 transition-all duration-300 hover:shadow-glow group">
              
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-12 h-12 rounded-full bg-bg-secondary flex items-center justify-center group-hover:bg-accent-primary/10 transition-colors">
                    <solution.icon className="w-6 h-6 text-text-primary group-hover:text-accent-primary transition-colors" />
                  </div>
                  <div className="text-xs font-medium px-2 py-1 rounded bg-bg-secondary text-text-secondary">
                    {solution.category}
                  </div>
                </div>

                <h3 className="text-xl font-bold text-text-primary mb-3 tracking-tightest">
                  {solution.title}
                </h3>

                <p className="text-text-secondary mb-6 flex-grow">
                  {solution.description}
                </p>

                <ul className="space-y-2 mb-8">
                  {solution.features.map((feature, idx) =>
                <li
                  key={idx}
                  className="flex items-start gap-2 text-sm text-text-secondary">
                  
                      <CheckCircle2 className="w-4 h-4 text-accent-secondary mt-0.5 shrink-0" />
                      <span>{feature}</span>
                    </li>
                )}
                </ul>

                <button className="flex items-center text-sm font-medium text-text-primary group-hover:text-accent-primary transition-colors mt-auto w-fit">
                  Learn more{' '}
                  <ArrowRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>

      <CTASection />
    </div>);

}