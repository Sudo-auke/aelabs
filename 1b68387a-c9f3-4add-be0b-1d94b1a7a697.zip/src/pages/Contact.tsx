import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { MapPin, Mail, Phone, UploadCloud, CheckCircle2 } from 'lucide-react';
type RequestType = 'Quote Request' | 'Technical Inquiry' | 'Partnership';
export function Contact() {
  const [requestType, setRequestType] = useState<RequestType>('Quote Request');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
      setTimeout(() => setIsSuccess(false), 5000);
    }, 1500);
  };
  return (
    <div className="pt-32 pb-24 min-h-screen max-w-7xl mx-auto px-6">
      <div className="mb-16 md:text-center">
        <motion.h1
          initial={{
            opacity: 0,
            y: 20
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          className="text-4xl md:text-6xl font-bold tracking-tightest text-text-primary mb-6">
          
          Let's build <span className="gradient-text">together.</span>
        </motion.h1>
        <motion.p
          initial={{
            opacity: 0,
            y: 20
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          transition={{
            delay: 0.1
          }}
          className="text-lg text-text-secondary max-w-2xl mx-auto">
          
          Discuss your project requirements with our engineering team. We
          typically respond within 24 hours.
        </motion.p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-12 lg:gap-24">
        {/* Form Section */}
        <motion.div
          initial={{
            opacity: 0,
            x: -20
          }}
          animate={{
            opacity: 1,
            x: 0
          }}
          transition={{
            delay: 0.2
          }}
          className="lg:col-span-3">
          
          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Request Type Selector */}
            <div className="flex flex-wrap gap-2 p-1 bg-bg-secondary rounded-lg w-fit">
              {(
              [
              'Quote Request',
              'Technical Inquiry',
              'Partnership'] as
              RequestType[]).
              map((type) =>
              <button
                key={type}
                type="button"
                onClick={() => setRequestType(type)}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${requestType === type ? 'bg-bg-surface text-text-primary shadow-sm border border-border' : 'text-text-secondary hover:text-text-primary'}`}>
                
                  {type}
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-medium text-text-primary">
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  className="w-full bg-bg-surface border border-border rounded-lg px-4 py-3 text-text-primary focus:outline-none focus:border-accent-primary focus:ring-1 focus:ring-accent-primary transition-all"
                  placeholder="Jane Doe" />
                
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-text-primary">
                  Work Email
                </label>
                <input
                  type="email"
                  required
                  className="w-full bg-bg-surface border border-border rounded-lg px-4 py-3 text-text-primary focus:outline-none focus:border-accent-primary focus:ring-1 focus:ring-accent-primary transition-all"
                  placeholder="jane@company.com" />
                
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-text-primary">
                  Company
                </label>
                <input
                  type="text"
                  required
                  className="w-full bg-bg-surface border border-border rounded-lg px-4 py-3 text-text-primary focus:outline-none focus:border-accent-primary focus:ring-1 focus:ring-accent-primary transition-all"
                  placeholder="Automotive Corp" />
                
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-text-primary">
                  Phone (Optional)
                </label>
                <input
                  type="tel"
                  className="w-full bg-bg-surface border border-border rounded-lg px-4 py-3 text-text-primary focus:outline-none focus:border-accent-primary focus:ring-1 focus:ring-accent-primary transition-all"
                  placeholder="+1 (555) 000-0000" />
                
              </div>
            </div>

            <div className="space-y-3">
              <label className="text-sm font-medium text-text-primary">
                Solutions of Interest
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {[
                'Embedded Software',
                'Engineering Tools',
                'Custom Hardware'].
                map((sol) =>
                <label
                  key={sol}
                  className="flex items-center gap-3 p-3 border border-border rounded-lg cursor-pointer hover:bg-bg-secondary transition-colors">
                  
                    <input
                    type="checkbox"
                    className="w-4 h-4 rounded border-border text-accent-primary focus:ring-accent-primary bg-bg-surface" />
                  
                    <span className="text-sm text-text-secondary">{sol}</span>
                  </label>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-text-primary">
                Project Details
              </label>
              <textarea
                required
                rows={5}
                className="w-full bg-bg-surface border border-border rounded-lg px-4 py-3 text-text-primary focus:outline-none focus:border-accent-primary focus:ring-1 focus:ring-accent-primary transition-all resize-none"
                placeholder="Tell us about your requirements, timeline, and technical constraints...">
              </textarea>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-text-primary">
                Attachments (Optional)
              </label>
              <div className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:bg-bg-secondary hover:border-accent-primary/50 transition-all cursor-pointer group">
                <UploadCloud className="w-8 h-8 text-text-secondary mx-auto mb-3 group-hover:text-accent-primary transition-colors" />
                <p className="text-sm text-text-primary font-medium mb-1">
                  Click to upload or drag and drop
                </p>
                <p className="text-xs text-text-secondary">
                  DBC, LDF, PDF, or ZIP (max 50MB)
                </p>
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting || isSuccess}
              className="w-full py-4 rounded-lg bg-text-primary text-bg-primary font-bold hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center justify-center gap-2">
              
              {isSubmitting ?
              <span className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-bg-primary border-t-transparent rounded-full animate-spin"></div>
                  Sending...
                </span> :
              isSuccess ?
              <span className="flex items-center gap-2 text-green-500">
                  <CheckCircle2 className="w-5 h-5" /> Message Sent
                </span> :

              'Submit Request'
              }
            </button>
          </form>
        </motion.div>

        {/* Info Section */}
        <motion.div
          initial={{
            opacity: 0,
            x: 20
          }}
          animate={{
            opacity: 1,
            x: 0
          }}
          transition={{
            delay: 0.3
          }}
          className="lg:col-span-2 space-y-10">
          
          <div className="p-8 rounded-2xl bg-bg-secondary border border-border">
            <h3 className="text-xl font-bold text-text-primary mb-6 tracking-tightest">
              Contact Information
            </h3>

            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-bg-surface flex items-center justify-center shrink-0 border border-border">
                  <MapPin className="w-5 h-5 text-accent-primary" />
                </div>
                <div>
                  <p className="font-medium text-text-primary mb-1">
                    Headquarters
                  </p>
                  <p className="text-sm text-text-secondary leading-relaxed">
                    Engineering Campus Stuttgart
                    <br />
                    Industriestraße 42
                    <br />
                    70565 Stuttgart, Germany
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-bg-surface flex items-center justify-center shrink-0 border border-border">
                  <Mail className="w-5 h-5 text-accent-secondary" />
                </div>
                <div>
                  <p className="font-medium text-text-primary mb-1">Email</p>
                  <a
                    href="mailto:hello@aelabs.dev"
                    className="text-sm text-text-secondary hover:text-accent-primary transition-colors">
                    
                    hello@aelabs.dev
                  </a>
                  <p className="text-xs text-text-secondary/70 mt-1">
                    PGP Key available upon request
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-bg-surface flex items-center justify-center shrink-0 border border-border">
                  <Phone className="w-5 h-5 text-text-primary" />
                </div>
                <div>
                  <p className="font-medium text-text-primary mb-1">Phone</p>
                  <a
                    href="tel:+497115550123"
                    className="text-sm text-text-secondary hover:text-text-primary transition-colors">
                    
                    +49 711 555 0123
                  </a>
                  <p className="text-xs text-text-secondary/70 mt-1">
                    Mon-Fri, 9:00 - 18:00 CET
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="rounded-2xl overflow-hidden border border-border h-64 relative bg-bg-secondary flex items-center justify-center">
            {/* Placeholder for a map */}
            <div
              className="absolute inset-0 opacity-20"
              style={{
                backgroundImage:
                'radial-gradient(circle at center, var(--text-primary) 1px, transparent 1px)',
                backgroundSize: '20px 20px'
              }}>
            </div>
            <div className="relative z-10 px-4 py-2 bg-bg-surface border border-border rounded-lg shadow-lg text-sm font-medium text-text-primary flex items-center gap-2">
              <MapPin className="w-4 h-4 text-accent-primary" /> Stuttgart
              Office
            </div>
          </div>
        </motion.div>
      </div>
    </div>);

}