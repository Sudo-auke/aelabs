import React from 'react';
import { Hero } from '../components/Hero';
import { TrustedBy } from '../components/TrustedBy';
import { SolutionCards } from '../components/SolutionCards';
import { Stats } from '../components/Stats';
import { CTASection } from '../components/CTASection';
export function Home() {
  return (
    <>
      <Hero />
      <TrustedBy />
      <SolutionCards />
      <Stats />
      <CTASection />
    </>);

}