import React, { useEffect, useState } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { Home } from './pages/Home';
import { Solutions } from './pages/Solutions';
import { Contact } from './pages/Contact';
import { About } from './pages/About';
type Page = 'home' | 'solutions' | 'contact' | 'about';
export function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  // Scroll to top on page change
  useEffect(() => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  }, [currentPage]);
  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <Home />;
      case 'solutions':
        return <Solutions />;
      case 'contact':
        return <Contact />;
      case 'about':
        return <About />;
      default:
        return <Home />;
    }
  };
  return (
    <div className="min-h-screen bg-bg-primary text-text-primary font-sans selection:bg-accent-primary/30 flex flex-col">
      <Header
        currentPage={currentPage}
        onNavigate={(page) => setCurrentPage(page as Page)} />
      
      <main className="flex-grow">{renderPage()}</main>
      <Footer />
    </div>);

}